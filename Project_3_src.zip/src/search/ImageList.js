import React from "react";

const Images_list = function(props){

    const images = props.images.map((image)=>{

        return <img src={image.webformatURL} key = {image.id}/>
    })
    return(
        <>
         
         {images}

        </>
    )
}

export default Images_list