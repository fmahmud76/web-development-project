import React from "react";
import Search_Input from "./SearchInput";
import axios from "axios";
import Images_list from "./ImageList";

class App extends React.Component {
    //set a state to store the response images in array
    state = {images:[]}
    //
    onSearchSubmit = async (e) =>  {
        
        const response =await axios.get(`https://pixabay.com/api/?key=43689437-1f117dc95ae9183a76f4cdc0f&q=${e}&image_type=photo`)

        console.log(response.data.hits)

        //setState to collect and transfer images into oour app

        this.setState({images:response.data.hits})
    }
    render() {
        return (
            <div className="ui container">
                <h1>Image Searcher</h1>
                <Search_Input onSearchSubmit={this.onSearchSubmit} />
                <Images_list images = {this.state.images}/>
            </div>
        )
    }
}

export default App;
