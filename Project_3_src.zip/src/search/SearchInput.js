import React from "react"

class Search_Input extends React.Component {
  
    state = { entry: "" }

    onSubmit = (e) => {
        e.preventDefault()
        console.log(this.state.entry)
        this.props.onSearchSubmit(this.state.entry)
    }

    render() {
        return (
            <div>
                <h2>Search Input</h2>
                <div className="ui segment">
                    <form className="ui form" onSubmit={this.onSubmit}>
                        <div className="ui field">
                            <div className="ui massive icon input">
                                <input
                                    type="text"
                                    placeholder="Type your search..."
                                    onChange={(e) => this.setState({ entry: e.target.value })}
                                    value={this.state.entry}
                                />
                                <i className="ui icon search"></i>
                            </div>
                        </div>
                    </form>
                </div>

            </div>
        )
    }
}

export default Search_Input;

