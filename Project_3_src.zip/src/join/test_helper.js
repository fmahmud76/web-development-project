// import mongoose

const mongoose = require('mongoose')

//connect to database, student_test --> db name
mongoose.connect('mongodb://localhost/student_test')

//check if connection is established

mongoose.connection
    //.once watches for mongodb to connect the first time the event occired
    .once('open',()=>{
        console.log('\n........connected to mongodb')
    }) 

    // .on watches for error in the connection
    .on('error', (error)=>{
        console.log('\n error connecting! ', error)
    })
    