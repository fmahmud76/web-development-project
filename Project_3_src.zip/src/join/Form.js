

import { useState } from 'react';


function Form() {
//import assert.assert is used to compare two boolean values
//const assert = require('assert')
const Student = require('.//student')

  {/**-----destructing from useState---- */}
  const[inputs, setInputs] = useState("")

  
  { {/**----submit the form---- */}
 // const submitform = function(event){
 //   event.preventDefault();
  //  alert(`Welcome to react form ${inputs.username}.\nComments : ${textcomments}`)
  }


  //create mongodb new data

  describe('Create the first data', ()=>{
    it('Save the student', ()=>{
        //create new student 
        const student1 = new Student({name:inputs.username},{password:inputs.password},{zip:inputs.zipcode})
        //save the information into the database
        student1.save()
        
        })
    
})

  {/** --chamges in form --- */}

  const handleChanges = function(event){
    const name = event.target.name;
    const value = event.target.value;
    setInputs(values => ({...values, [name]: value}))
  } 



  return (
    <div>
      <form onSubmit={describe}>
        <fieldset>
          <legend>New Customer</legend>
          
          {/** --set username --- */}
          <label for="name">Enter a name:</label>
          <input 
            type='text' 
            id='name'
            name = "username"
            placeholder='Type usernaame...'
            value = {inputs.username}
            onChange = {handleChanges}
            required
            />

            <label for="password">Enter a Password:</label>
            <input 
            type='text' 
            id='pass'
            name = "password"
            placeholder='Type password...'
            value = {inputs.password}
            onChange = {handleChanges}
            required
            />
            
            <label for="zipcode">Enter a Zip Code:</label>
          <input 
            type='text' 
            id='zip'
            name = "zipcode"
            placeholder='Type zipcode...'
            value = {inputs.zipcode}
            onChange = {handleChanges}
            required
            />
            
            {/*submit form*/}
            <div style = {{marginTop:"1em"}}>
              <input type = 'submit'/>
            </div>
        </fieldset>
      </form>
      
    </div>
  );
}

export default Form;
